module.exports = {
	input: 'src/user-processes.js',
	output: {
		js: 'script.js',
		css: 'style.css',
	},
	namespace: 'BX.Bizproc.Component',
	browserslist: true,
};
